import employees.*;
import inventory.*;
import orders.*;
import data.*;

import java.util.Scanner;

public class CompanySystem {
    private static CompanySystem instance;
    private EmployeeManager employeeManager;
    private InventoryManager inventoryManager;
    private OrderManager orderManager;
    private OrderProcessing orderProcessing;

    private Scanner scanner;

    private CompanySystem() {
        employeeManager = new EmployeeManager();
        inventoryManager = new InventoryManager();
        orderManager = new OrderManager();
        orderProcessing = new OrderProcessing(inventoryManager);
        scanner = new Scanner(System.in);
    }

    public static CompanySystem getInstance() {
        if (instance == null) {
            instance = new CompanySystem();
        }
        return instance;
    }

    public void start() {
        System.out.println("--- Podnikový systém spuštěn ---");
        System.out.println("Základní ukázkové operace:");

        employeeManager.addEmployee("Anna", "Nováková", "Manažer", 45000);
        employeeManager.addEmployee("Petr", "Dvořák", "Technik", 33000);
        employeeManager.printAllEmployees();

        orderManager.createOrder("Web aplikace", "Tvorba systému", "Přijata", "2025-05-01", "2025-06-01");
        orderManager.printActiveOrders();

        inventoryManager.addItem("Notebook", 1, 5, 3);
        inventoryManager.addItem("Myš", 2, 15, 5);
        inventoryManager.checkLowStock();

        orderProcessing.processOrder("Notebook", 2);
        orderProcessing.processOrder("Notebook", 5);
    }
}