package data;

public class DataLogger {
    public static void log(String message) {
        System.out.println("[INFO] " + message);
    }

    public static void warning(String message) {
        System.out.println("[VAROVÁNÍ] " + message);
    }

    public static void error(String message) {
        System.err.println("[CHYBA] " + message);
    }
}
