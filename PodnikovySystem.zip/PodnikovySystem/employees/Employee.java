package employees;

public class Employee {
    private static int counter = 1;
    private int id;
    private String name;
    private String surname;
    private String position;
    private double salary;

    public Employee(String name, String surname, String position, double salary) {
        this.id = counter++;
        this.name = name;
        this.surname = surname;
        this.position = position;
        this.salary = salary;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getSurname() { return surname; }
    public String getPosition() { return position; }
    public double getSalary() { return salary; }

    @Override
    public String toString() {
        return id + ": " + name + " " + surname + " | " + position + " | Plat: " + salary + " Kč";
    }
}
