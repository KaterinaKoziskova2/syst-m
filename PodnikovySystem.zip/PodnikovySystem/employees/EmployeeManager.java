package employees;

import java.util.*;

public class EmployeeManager {
    private List<Employee> employees = new ArrayList<>();

    public void addEmployee(String name, String surname, String position, double salary) {
        employees.add(new Employee(name, surname, position, salary));
    }

    public void printAllEmployees() {
        System.out.println("Zaměstnanci:");
        for (Employee e : employees) {
            System.out.println(e);
        }
    }

    public Employee findEmployeeById(int id) {
        for (Employee e : employees) {
            if (e.getId() == id) return e;
        }
        return null;
    }

    public double getTotalSalaryCost() {
        double sum = 0;
        for (Employee e : employees) sum += e.getSalary();
        return sum;
    }
}
