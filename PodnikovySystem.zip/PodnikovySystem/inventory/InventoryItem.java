package inventory;

public class InventoryItem {
    private String name;
    private int id;
    private int quantity;
    private int minStock;

    public InventoryItem(String name, int id, int quantity, int minStock) {
        this.name = name;
        this.id = id;
        this.quantity = quantity;
        this.minStock = minStock;
    }

    public String getName() { return name; }
    public int getId() { return id; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getMinStock() { return minStock; }
}