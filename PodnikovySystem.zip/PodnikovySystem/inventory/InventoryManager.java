package inventory;

import java.util.*;

public class InventoryManager {
    private List<InventoryItem> items = new ArrayList<>();

    public void addItem(String name, int id, int quantity, int minStock) {
        items.add(new InventoryItem(name, id, quantity, minStock));
    }

    public InventoryItem findItem(String name) {
        for (InventoryItem item : items) {
            if (item.getName().equalsIgnoreCase(name)) return item;
        }
        return null;
    }

    public void checkLowStock() {
        System.out.println("Nízký stav zásob:");
        for (InventoryItem item : items) {
            if (item.getQuantity() < item.getMinStock()) {
                System.out.println(item.getName() + " (" + item.getQuantity() + ") je pod minimem: " + item.getMinStock());
            }
        }
    }
}
