package orders;

public class Order {
    private static int counter = 1;
    private int id;
    private String name;
    private String description;
    private String status;
    private String dateReceived;
    private String deadline;

    public Order(String name, String description, String status, String dateReceived, String deadline) {
        this.id = counter++;
        this.name = name;
        this.description = description;
        this.status = status;
        this.dateReceived = dateReceived;
        this.deadline = deadline;
    }

    public int getId() { return id; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return id + ": " + name + " | Stav: " + status + " | Do: " + deadline;
    }
}