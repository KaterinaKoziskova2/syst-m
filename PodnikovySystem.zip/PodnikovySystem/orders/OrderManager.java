package orders;

import java.util.*;

public class OrderManager {
    private List<Order> orders = new ArrayList<>();

    public void createOrder(String name, String description, String status, String dateReceived, String deadline) {
        orders.add(new Order(name, description, status, dateReceived, deadline));
    }

    public void printActiveOrders() {
        System.out.println("Aktivní zakázky:");
        for (Order order : orders) {
            if (!order.getStatus().equalsIgnoreCase("Dokončena")) {
                System.out.println(order);
            }
        }
    }

    public Order findById(int id) {
        for (Order o : orders) {
            if (o.getId() == id) return o;
        }
        return null;
    }
}
