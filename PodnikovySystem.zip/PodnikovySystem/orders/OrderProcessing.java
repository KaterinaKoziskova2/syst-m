package orders;

import inventory.*;

public class OrderProcessing {
    private InventoryManager inventoryManager;

    public OrderProcessing(InventoryManager inventoryManager) {
        this.inventoryManager = inventoryManager;
    }

    public void processOrder(String itemName, int quantity) {
        InventoryItem item = inventoryManager.findItem(itemName);
        if (item == null) {
            System.out.println("Položka " + itemName + " nebyla nalezena ve skladu.");
            return;
        }

        if (item.getQuantity() >= quantity) {
            item.setQuantity(item.getQuantity() - quantity);
            System.out.println("Objednávka na " + quantity + " ks " + itemName + " byla zpracována.");
        } else {
            System.out.println("Nedostatek zásob pro položku: " + itemName + ". Dostupné: " + item.getQuantity());
        }
    }
}
